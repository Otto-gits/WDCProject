const mysql = require('mysql');
const connection = mysql.createConnection({
  // host: '127.0.0.1',
  host: 'localhost',
  // user: 'root',
  // password: 'newpassword',
  database: 'watchawatchin'
});

module.exports = connection;
