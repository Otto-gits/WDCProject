#!/bin/bash
npm install express
npm install xss-clean
sudo service mysql start
mysql -u root -p < db_dump.sql
echo "======================================="
echo "   Welcome to WatchaWatchin! 🎬🍿"
echo "======================================="
npm start
