var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const db = require('./db');
const bcrypt = require('bcrypt');
const session = require('express-session');
const axios = require('axios');
const multer = require('multer');
const sharp = require('sharp');
const fs = require('fs');
const xss = require('xss-clean');
require('dotenv').config({ path: './routes/hidden.env' });

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static('public'));
app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false }
}));
app.use(xss());
// USE statement to create a session
app.use((req, res, next) => {
  res.locals.session = req.session;
  next();
});

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Upload so that users can upload an avatar when creating an account
const upload = multer({
  dest: 'uploads/', // temp upload folder
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
      cb(null, true);
    } else {
      cb(new Error('Only JPEG and PNG are allowed'));
    }
  }
});

// POST request for the register page
app.post('/register', upload.single('avatar'), async (req, res) => {
  // Call the racaptcha key from the .ENV file
  const secretKey = process.env.RecaptchaKey;
  const recaptchaResponse = req.body['g-recaptcha-response'];

  try { // Post RECAPTCHA data
    const response = await axios.post(
      `https://www.google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${recaptchaResponse}`
    );
    if (!response.data.success) {
      return res.render('registrationmessages', {
        title: 'reCAPTCHA Failed',
        stylesheet: '/stylesheets/register.css',
        heading: 'reCAPTCHA verification failed!',
        message: '<a href="/register.html">Try again</a>'
      });
    }
  } catch (err) {
    return res.status(500).send('Error verifying reCAPTCHA');
  }

  // Check if the request body has email and password
  const { email, password } = req.body;
  let services = req.body.services || [];
  if (Array.isArray(services)) {
    services = services.join(',');
  }

  // Avatar processing
  let avatarPath = null;
  if (req.file) {
    try {
      const outputDir = path.join(__dirname, 'public', 'avatars');
      if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });
      const ext = path.extname(req.file.originalname).toLowerCase();
      const filename = `${Date.now()}_${req.file.filename}${ext}`;
      avatarPath = `/avatars/${filename}`;
      await sharp(req.file.path)
        .resize(48, 48)
        .toFile(path.join(outputDir, filename));
      fs.unlinkSync(req.file.path); // remove temp file
    } catch (err) {
      return res.status(500).send('Error processing avatar: ' + err.message);
    }
  }

  // Check if email and password are provided
  db.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {
    if (err) return res.status(500).send('Database error');
    if (results.length > 0) {
      return res.render('registrationmessages', {
        title: 'User already exists',
        stylesheet: '/stylesheets/register.css',
        heading: 'User already exists !',
        message: '<a href="/login.html">Login here</a>'
      });
    }
    bcrypt.hash(password, 10, (errInner, hash) => {
      if (errInner) return res.status(500).send('Error hashing password');
      db.query(
        'INSERT INTO users (email, password_hash, streaming_services, avatar) VALUES (?, ?, ?, ?)',
        [email, hash, services, avatarPath],
        (error) => {
          if (error) return res.status(500).send('Database error');
          res.render('registrationmessages', {
            title: 'Account Created',
            stylesheet: '/stylesheets/register.css',
            heading: 'Account created!',
            message: '<a href="/login.html">Login here</a>'
          });
          return res.status(200); // Satifies linting errors
        }
      );
      return res.status(200); // Satifies linting errors
    });
    return res.status(200); // Satifies linting errors
  });
  return res.status(200); // Satifies linting errors
});

// Use avatars route
app.use('/avatars', express.static(path.join(__dirname, 'public/avatars')));

// Login route
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  db.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {

    if (err) return res.status(500).send('Database error');

    if (results.length === 0) {
      return res.render('registrationmessages', {
        title: 'User not found',
        stylesheet: '/stylesheets/login.css',
        heading: 'User not found!',
        message: '<a href="/register.html">Register here</a>'
      });
    }

    const user = results[0];
    bcrypt.compare(password, user.password_hash, (errorCompare, match) => {
      if (errorCompare) return res.status(500).send('Error checking password');
      if (match) {
        req.session.avatar = user.avatar;
        req.session.userId = user.id;
        return res.render('registrationmessages', {
          title: 'Login Successful',
          stylesheet: '/stylesheets/login.css',
          heading: 'Login successful!',
          message: '<a href="/">Go to homepage</a>'
      });
    }
    return res.render('registrationmessages', {
        title: 'Login Failed',
        stylesheet: '/stylesheets/login.css',
        heading: 'Login failed!',
        message: '<a href="/login.html">Try again</a>'
    });
    });
    return res.status(200); // Satifies linting errors
  });
});

// Get the show by ID from the streaming-availability API
const getShowByID = async (id) => {
  if (!id) {
    throw new Error('ID is required');
  }
  const options = {
    method: 'GET',
    url: 'https://streaming-availability.p.rapidapi.com/shows/' + id,
    params: {
      country: 'au',
      output_language: 'en'
    },
    headers: {
      'x-rapidapi-key': '3e848026famsh802452896a87a88p118152jsn593fcd88b869',
      'x-rapidapi-host': 'streaming-availability.p.rapidapi.com'
    }
  };
  try {
    const response = await axios.request(options);
    const results = response.data;
    return results;
  } catch (error) {
    // maybe this insted of the line below?= res.status(500).send('Error fetching show by ID');
        throw new Error('Error fetching show by ID');
  }
};

// Add a movie to the user's watchlist
app.post('/add-to-watchlist', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).send('Not logged in');
  }
  const { media_id, media_name } = req.body;
  db.query(
    'SELECT * FROM watchlist WHERE user_id = ? AND media_id = ?',
    [req.session.userId, media_id],
    (err, results) => {
      if (err) {
        return res.status(500).send('Database error');
      }
      db.query(
        'INSERT INTO watchlist (user_id, media_id, media_name) VALUES (?, ?, ?)',
        [req.session.userId, media_id, media_name],
        (err2) => {
          if (err2) {
            return res.status(500).send('Database error');
          }
          res.redirect('/watchlist');
          return res.status(200); // Satifies linting errors
        }
      );
      return res.status(200); // Satifies linting errors
    }
  );
  return res.status(200); // Satifies linting errors
});

// Remove a movie from the user's watchlist
app.post('/remove-from-watchlist', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).send('Not logged in');
  }
  const { media_id } = req.body;
  db.query(
    'DELETE FROM watchlist WHERE user_id = ? AND media_id = ?',
    [req.session.userId, media_id],
    (err) => {
      if (err) {
        return res.status(500).send('Database error');
      }
      res.redirect('/watchlist');
      return res.status(200); // Satifies linting errors
    }
  );
  return res.status(200); // Satifies linting errors
});


// Show the user's watchlist
app.get('/watchlist', async (req, res) => {
  db.query(
    'SELECT * FROM watchlist WHERE user_id = ?',
    [req.session.userId],
    async (err, results) => {
      if (err) {
        return res.status(500).send('Database error');
      }
      try {
        // Fetch all show details in parallel
        const shows = await Promise.all(
          results.map((item) => getShowByID(item.media_id))
        );
        res.render('watchlist', { shows, session: req.session });
      } catch (e) {
        res.status(500).send('Error fetching movie details');
      }
      return res.status(200); // Satifies linting errors
    }
  );
});

// Rate a move (add or update rating)
app.post('/rate-movie', (req, res) => {
  if (!req.session.userId) return res.status(401).send('Not logged in');

  const { media_id, rating } = req.body;

  // Basic validation – keep bad/malicious values out of the DB
  if (![1, 2, 3, 4, 5].includes(Number(rating))) return res.status(400).send('Rating must be 1-5');

  db.query(
    `INSERT INTO ratings (user_id, media_id, rating)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE rating = VALUES(rating)`,
    [req.session.userId, media_id, rating],
    (err) => {
      if (err) {
        return res.status(500).send('Database error');
      }
      return res.redirect(`/movie-details?id=${media_id}`);
    }
  );
  return res.status(200); // Satifies linting errors
});

// Show account management page
app.get('/accountmanagement', (req, res) => {
  if (!req.session.userId) {
    // Render the page with a message, not a redirect
    return res.render('accountmanagement', { user: null, session: req.session });
  }
  db.query(
    'SELECT * FROM users WHERE id = ?',
    [req.session.userId],
    (err, results) => {
      if (err || results.length === 0) {
        return res.render('accountmanagement', { user: null, session: req.session });
      }
      res.render('accountmanagement', { user: results[0], session: req.session });
      return res.status(200); // Satifies linting errors
    }
  );
  return res.status(200); // Satifies linting errors
});

// Update user's streaming services in accoutn management
app.post('/accountmanagement', (req, res) => {
  if (!req.session.userId) return res.status(401).send('Not logged in');
  let streaming_services = req.body.streaming_services || [];
  if (!Array.isArray(streaming_services)) streaming_services = [streaming_services];
  streaming_services = streaming_services.filter(Boolean).join(',');

  db.query(
    'UPDATE users SET streaming_services = ? WHERE id = ?',
    [streaming_services, req.session.userId],
    (err) => {
      if (err) {
        return res.status(500).send('Database error: ' + err.sqlMessage);
      }
      res.redirect('/accountmanagement');
      return res.status(200); // Satifies linting errors
    }
  );
  return res.status(200); // Satifies linting errors
});

// Log out the user and destroy the session
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login.html');
  });
});

// Render the home page, fetching the user's avatar if logged in
app.get('/', (req, res) => {
  if (req.session.userId) {
    db.query('SELECT avatar FROM users WHERE id = ?', [req.session.userId], (err, results) => {
      let avatar = '/avatars/default-avatar.png';
      if (!err && results.length > 0 && results[0].avatar) {
        avatar = results[0].avatar;
      }
      // Pass avatar as part of session for EJS
      res.render('index', {
        session: { ...req.session, avatar }
      });
    });
  } else {
    res.render('index', {
      session: req.session
    });
  }
});

// Render the about page
app.get('/about', (req, res) => {
  res.render('about');
});

module.exports = app;
