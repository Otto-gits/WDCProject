/* global grecaptcha */

// Linting errors forceably removed to allow grecaptcha usage
// Whilst also ensuring linting erros are not present

// eslint-disable-next-line no-unused-vars
function onRecaptchaSuccess() {
  document.getElementById('formFields').style.display = 'block';
}

document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('registerForm').addEventListener('submit', function (e) {
    if (grecaptcha.getResponse() === "") {
      e.preventDefault();
      // eslint-disable-next-line no-alert
      alert('Please confirm that you are not a robot.');
    }
  });
});
