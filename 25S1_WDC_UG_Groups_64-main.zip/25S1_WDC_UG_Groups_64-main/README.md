# Group Repository for COMP SCI 2207/7207 Web & Database Computing Web Application Project (2025 Semester 1)
>Order of speaking:
Lachlan Keep
Otto Hedger
Lachlan Hennessy
Matthew Sutton

>Overview:
WatchWatchin is a website application that helps users discover where to watch their favourite movies and shows across many streaming services, Netflix, Prime, Stan, Disney+, and more, all from one convenient platform.

>Project Description:
Sick of going onto Netflix and not finding that movie you’ve been itching to watch all week? Most of the time, I just leave it there and give up, without even bothering to check Prime, Stan or Disney+. Not for much longer! WatchWatchin is the freshest innovation to this everyday issue.

WatchaWatchin is a mastery of API call engineering, webpage design skills, and user requirements engineering, allowing our target audience's experience to be enhanced through the convenience of a single site for all things streaming, movie research and straming availability!

>Setup Guide
You may run the webpage by running the command:
./watcha-watchin.sh and use password "newpassword"
This is a shell script file executing a bash command to run all the startup commands in one command. This ensures both convenience and operability for users.

Else, you may run the webpage through the following list of commands:

npm install express
sudo service mysql start
mysql -u root < db_dump.sql
npm start

>Features and Functionality:
- 🔍 Search for Movies, and Tv shows
- ⭐ Save media to your Personal Watchlist
- 🧠 Get platform-specific availability based on subscriptions the user holds
- 🎞️ View top trending content
- 💬 Rate what you've seen

>Known Bugs/Limitations
<Limitations
-Speed of the API, as it is run on a free plan, so paid plans would have higher call speeds. This is generally not noticeable/ has a negligable effect on the operation of the site.
-API does not have images/ descriptions for all Media. This is a rare occurance for most well known movies.
-Limit of API calls per month. Free plan has a 1000 call per month limit. During development our group
purchased a higher monthly plan of 12,000 calls per month. This has expired and has reverted to the free plan.

<Bugs
-All known bugs have been elimated, or are limitations of the API/ software.


https://docs.google.com/document/d/1UfDfstyIdkFKkCbsC2adrDWUAti50V8w0k_hAWt3yJ4/edit?usp=sharing