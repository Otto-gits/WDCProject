var express = require('express');
var router = express.Router();
const streamingAvailability = require("streaming-availability");
var axios = require('axios');
const db = require('../db');
const fs = require('fs');
const path = require('path');

// call API key from .ENV file
const API_KEY = process.env.APIKEY;

// Define the getShow function to return the API data for a show
// given a certain show ID
const getShow = async () => {
  // Create a variable for the API client
  const client = new streamingAvailability.Client(
    new streamingAvailability.Configuration({
      apiKey: API_KEY
    })
  );

  // Call the data
  const data = await client.showsApi.getShow({
    id: "tt10048342"
  });

  return data;
};

// API route to fetch show data and send it as JSON
router.get('/api/getshow', async (req, res) => {
  try {
    const data = await getShow(); // get data from getShow() function
    res.json(data); // Send the data as JSON
  } catch (error) {
    error('Error fetching show data:', error);
    res.status(500).json({ error: 'Failed to fetch show data' });
  }
});

// Function to return the top show in the API for a given title
const getTopShow = async (input) => {
  if (!input) {
    throw new Error('Title is required');
  }

  // Define options for the API call
  const options = {
    method: 'GET',
    url: 'https://streaming-availability.p.rapidapi.com/shows/search/title',
    params: {
      country: 'au',
      title: input,
      series_granularity: 'show',
      output_language: 'en'
    },
    headers: {
      'x-rapidapi-key': '3e848026famsh802452896a87a88p118152jsn593fcd88b869',
      'x-rapidapi-host': 'streaming-availability.p.rapidapi.com'
    }
  };

  // Do a request using the defined input and options
  try {
    const response = await axios.request(options);
    const results = response.data;

    return results[0]; // Return the first result

  } catch (error) {
    error('Error in getTopShow:', error.message);
    throw error;
  }
};

// Function to call a list of shows data from the API using a search
// that related to the title
const getSearchResults = async (input) => {
  if (!input) {
    throw new Error('Search term is required');
  }
  // Define the search options
  const options = {
    method: 'GET',
    url: 'https://streaming-availability.p.rapidapi.com/shows/search/title',
    params: {
      country: 'au',
      title: input,
      series_granularity: 'show',
      output_language: 'en'
    },
    headers: {
      'x-rapidapi-key': '3e848026famsh802452896a87a88p118152jsn593fcd88b869',
      'x-rapidapi-host': 'streaming-availability.p.rapidapi.com'
    }
  };
  const response = await axios.request(options);
  const results = response.data;
  return results;
};

// GET request for the search page
// Calls the shows for a given search and checks to see if any shows
// have the streaming service stored to the user's account
router.get('/search', async function (req, res) {
  try {
    // Define a query
    const { query } = req.query;

    if (!query || query.trim().length === 0) { // if a search was empty
      return res.redirect('/'); // return to home page
    }

    // Get the search results from this query
    const showsFromSearch = await getSearchResults(query);

    let streamingServices = [];
    if (req.session.userId) { // if the user has logged into account
      // Query the database for the user's streaming services
      db.query(
        'SELECT streaming_services FROM users WHERE id = ?',
        [req.session.userId],
        (err, results) => {
          if (!err && results.length > 0) {
            streamingServices = results[0].streaming_services ? results[0].streaming_services.split(',') : [];
          }
          // Render the streaming services they have associated with the account
          // and the search results
          res.render('search', {
            title: 'Search Results',
            shows: showsFromSearch,
            session: req.session,
            streamingServices
          });
          return res.status(200);
        }
      );
    } else { // If there is no signed in account
      // Only return the search results
      res.render('search', {
        title: 'Search Results',
        shows: showsFromSearch,
        session: req.session,
        streamingServices
      });
      return res.status(200);
    }
  } catch (error) {
    res.status(500).send('Failed to load movie details');
  }
  return res.status(200);
});

// Function to make an API call using a show's ID
const getShowByID = async (id) => {
  if (!id) {
    throw new Error('ID is required');
  }
  // Define the options for the search using the givven ID
  const options = {
    method: 'GET',
    url: 'https://streaming-availability.p.rapidapi.com/shows/' + id,
    params: {
      country: 'au',
      output_language: 'en'
    },
    headers: {
      'x-rapidapi-key': '3e848026famsh802452896a87a88p118152jsn593fcd88b869',
      'x-rapidapi-host': 'streaming-availability.p.rapidapi.com'
    }
  };
  try {
    // Returns the data from the APi call
    const response = await axios.request(options);
    const results = response.data;
    return results;
  } catch (error) {
    error('Error in getShowByID:', error.message);
    throw error;
  }
};

// Function to get the top 20 shows of all time from API
const getTop20Shows = async () => {
  // Define the options, ordering the call by all time popularity
  const options = {
    method: 'GET',
    url: 'https://streaming-availability.p.rapidapi.com/shows/search/filters',
    params: {
      country: 'au',
      series_granularity: 'show',
      order_by: 'popularity_alltime',
      output_language: 'en'
    },
    headers: {
      'x-rapidapi-key': '3e848026famsh802452896a87a88p118152jsn593fcd88b869',
      'x-rapidapi-host': 'streaming-availability.p.rapidapi.com'
    }
  };
  try {
    // Call the API and return the results
    const response = await axios.request(options);
    const results = response.data;
    return results;
  } catch (error) {
    error('Error in getTop20Shows:', error.message);
    throw error;
  }
};

// Create paths to the last API call and top20 json files
const lastDatePath = path.join(__dirname, 'lastApiCall.json');
const top20Path = path.join(__dirname, 'top20.json');

// Function to return the top 20 shows only once a day to limit
// the number of API calls
const getOnceaDay = async () => {
  // Assign the current date to a variable
  const current_d = new Date().getDate().toString();
  let last = null;

  if (fs.existsSync(lastDatePath)) { // If there is a previous last date
    const meta = JSON.parse(fs.readFileSync(lastDatePath, 'utf-8'));
    last = meta.lastCall;
  }

  // If the current date is different to the last date or the top20.json file does not exist
  if (!last || last !== current_d || !fs.existsSync(top20Path)) {
    const data = await getTop20Shows();

    // Save new date and data
    fs.writeFileSync(lastDatePath, JSON.stringify({ lastCall: current_d }));
    fs.writeFileSync(top20Path, JSON.stringify(data, null, 2));
  }

  // Load cached data from json file and return it
  const top20 = JSON.parse(fs.readFileSync(top20Path, 'utf-8'));
  return top20;
};

// GET request for the data associated with highlighted movie details
router.get('/movie-details', async (req, res) => {
  try {
    const { title, id } = req.query; // ?title= or ?id=
    if (!title && !id) {
      return res.status(400).send('Title or ID query parameter is required');
    }
    let movie; // will hold the show object
    if (id) {
      movie = await getShowByID(id);
    } else {
      movie = await getTopShow(title);
    }

    // Also pull the shows with a similar name
    const similarShows = await getSearchResults(movie.title);

    let userRating = null;
    if (req.session.userId) {
      const mediaId = id || movie.imdbId || movie.IMDbId;
      // Check if in ratings and watchlist
      db.query(
        'SELECT rating FROM ratings WHERE user_id = ? AND media_id = ? LIMIT 1',
        [req.session.userId, mediaId],
        (err, rows) => {
          if (err) {
            return res.status(500).send('DB error');
          }
          userRating = rows.length ? Number(rows[0].rating) : null;
          db.query(
            'SELECT 1 FROM watchlist WHERE user_id = ? AND media_id = ? LIMIT 1',
            [req.session.userId, mediaId],
            (err2, watchRows) => {
              if (err2) {
                return res.status(500).send('DB error');
              }
              const inWatchlist = watchRows.length > 0;
              res.render('movie-details', {
                title: 'Movie Details',
                movie,
                recom: similarShows.slice(1, 6),
                session: req.session,
                userRating,
                inWatchlist
              });
              return res.status(200);
            }
          );
          return res.status(200);
        }
      );
      return res.status(200);
    }
    // If the user is not logged in
    res.render('movie-details', {
      title: 'Movie Details',
      movie,
      recom: similarShows.slice(1, 6), // only send top 5 similar shows
      session: req.session,
      userRating: null,
      inWatchlist: false
    });
    return res.status(200);
  } catch (error) {
    res.status(500).send('Failed to load movie details');
  }
  return res.status(200);
});

// Get function to send the top 20 shows to the home page
// either from an API call or a json file
router.get('/', async function (req, res) {
  try {
    // Call json data
    const topShows = await getOnceaDay();
    res.render('index', {
      shows: topShows.shows || [],
      session: req.session
    });
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

module.exports = router;
